let digite = parseFloat(prompt("Primeiro numero"));

let numeroquadrado = digite * digite
document.write(numeroquadrado);
