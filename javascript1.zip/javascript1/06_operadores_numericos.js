let idadeInstrutor = "31";
console.log(idadeInstrutor);
console.log(typeof idadeInstrutor);

let numero1 = 27;
let numero2 = 33;

let soma = numero1 + numero2;
let subtrair = numero1 - numero2;
let multiplicar = numero1*numero2;
let dividir = numero1 / numero2;

console.log(soma);
console.log(subtrair);
console.log(multiplicar);
console.log(dividir);




