// console.log("olá Mundo!)
// let nomealuna = "Amanda" ; // STR , string
// let idadealuna = 20; // number int
// let alturaaluna = 1.64; // nuber float
// console.log(nomealuna);
//console.log(idadealuna);
//console.log(alturaaluna);


//cammelCase

let nomeAluna = "Amanda"; // STR.string
let idadeAluna = 20; // number int
let alturaAluna = 1.64; // number float

//snake_case

let nome_aluna = "Amanda"; //STR, string
let idade_aluna= 20; // number float
let altura_aluna= 1.64; // number float

//reatribuição

let mensagemUsuario = "Seja bem vindo";
console.log(mensagemUsuario);

mensagemUsuario="Boa tarde";
console.log(mensagemUsuario);

mensagemUsuario= 33;
console.log(mensagemUsuario);

//alert(mensagemUsuario)
//document.write(mensagemUsuario);
prompt();
//console.log(); // Exibir a informação no console (Navegador ou exensão)

//Informações prompt

let nomeUsuario= prompt ("Informe o seu nome: ");

alert(mensagemUsuario);




