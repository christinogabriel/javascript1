let numero1 = parseFloat(prompt("Informe o primeiro número "));
let numero2 = parseFloat(prompt("Informe o segundo número "));

let soma = numero1 + numero2;
alert(soma);





