let numero1 = parseFloat(prompt("Numero 1"));
let numero2 = parseFloat(prompt("Numero 2"));

let soma = numero1 + numero2;
let subtração = numero1 - numero2;
let multiplicação = numero1 * numero2;
let divisão = numero1 / numero2;


document.write(soma);
document.write("<br>");
document.write(subtração);
document.write("<br>");
document.write(multiplicação);
document.write("<br>");
document.write(divisão);


