let anoNasc = prompt("Ano de Nascimento");
let anoFuturo = 2030

let calcPrevisão = anoFuturo - anoNasc;

document.write (calcPrevisão);