let digite = prompt("Digite seu nome");
let mensagembody = "Seja Bem Vindo! Gabriel"
document.write(mensagembody);