let mensagem = "Você é lindo!";
let nomeInstrutor = "Gb ";

let mensagemCompleta = nomeInstrutor + mensagem ;

console.log(mensagemCompleta);


